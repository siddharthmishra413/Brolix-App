app.controller('manageAdminToolsCtrl', function ($scope, $window, userService, $state, toastr, $http, $timeout) {
$(window).scrollTop(0,0);
 $scope.$emit('headerStatus', 'Admin Tools');
 $scope.$emit('SideMenu', 'Admin Tools');


})